package com.alojamiento.alojamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlojamientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlojamientoApplication.class, args);
	}

}
